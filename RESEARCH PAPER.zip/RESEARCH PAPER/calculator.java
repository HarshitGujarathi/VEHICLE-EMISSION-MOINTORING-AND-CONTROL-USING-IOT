class Calculator:
    def __init__(self):
        self.result = 0

    def add(self, num):
        self.result += num

    def subtract(self, num):
        self.result -= num

    def multiply(self, num):
        self.result *= num

    def divide(self, num):
        if num == 0:
            print("Error: Division by zero")
        else:
            self.result /= num

    def display_result(self):
        print("Result:", self.result)

# Create an instance of the Calculator class
calculator = Calculator()

while True:
    print("Options:")
    print("Enter 'add' for addition")
    print("Enter 'subtract' for subtraction")
    print("Enter 'multiply' for multiplication")
    print("Enter 'divide' for division")
    print("Enter 'quit' to end the program")

    user_input = input(": ")

    if user_input == "quit":
        break
    elif user_input in ["add", "subtract", "multiply", "divide"]:
        num = float(input("Enter a number: "))
        if user_input == "add":
            calculator.add(num)
        elif user_input == "subtract":
            calculator.subtract(num)
        elif user_input == "multiply":
            calculator.multiply(num)
        elif user_input == "divide":
            calculator.divide(num)
    else:
        print("Invalid input")

calculator.display_result()
